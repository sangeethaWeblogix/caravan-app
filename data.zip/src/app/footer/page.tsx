import React from 'react'
import Footer from './Footer'

const page = () => {
  return (
    <div>
      
      <Footer />
    </div>
  )
}

export default page
